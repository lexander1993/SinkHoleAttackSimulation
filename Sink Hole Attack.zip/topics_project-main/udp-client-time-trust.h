extern int negative_values[9];
extern int positive_values[9];
extern uip_ipaddr_t neighbors[9];

