extern int attack_flag_sinkhole;
