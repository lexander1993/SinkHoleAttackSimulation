extern int negative_value;
extern int positive_value;
extern int endOfIp;
extern uip_ipaddr_t trustAddress;

extern int br_curr_negative_values[9];
extern int br_curr_positive_values[9];
extern int br_curr_neighbors[9];
extern int new_data;

